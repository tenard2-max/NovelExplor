# 99_Master_DB

## Project

- Title: (Working)
- Timeline Start: 2005-03-02
- Original Timeline: 2080
- Story Status: EP001~EP007

# Character DB

  ----------------------------------------------------------------------------------
  ID      Name     Role     First EP     Future Role     Alive    Boss    Notes
  ------- -------- -------- ------------ --------------- -------- ------- ----------
  CH001   주인공   회귀자   EP001        인류 구원       Y        N       100세 이상 회귀
  CH002   AI 폰    AI       EP001        최종보스        Y        Final   노인 케어 AI
  CH003   민수     친구     EP002        최강 방패       Y        예정    맵부심
  CH004   지은     첫사랑   EP003        보호 대상       Y        N       평범한 인간
  CH005   수아     친구     EP004        핵심 조력자     Y        N       후반 비중 증가
  CH006   아버지   가족     EP007        투자 지원       Y        N       중견기업 오너
  ----------------------------------------------------------------------------------

# Foreshadow DB

  ID     EP      Foreshadow   Planned Payoff   Status
  ------ ------- ------------ ---------------- --------
  F001   EP001   마지막 1초   최종부           OPEN
  F002   EP001   AI의 사과    최종부           OPEN
  F003   EP004   위성 이상    게이트 전조      OPEN
  F004   EP006   97%          최종부           OPEN

# Investment DB

  Phase   Capital   Goal                 Status
  ------- --------- -------------------- --------
  Seed    58.7억    초기 투자            진행
  P1      100억     기반 구축            예정
  P2      1조       기업 확보            예정
  P3      100조     전략 자산            예정
  Final   1000조    인류 생존 프로젝트   예정

# Boss Progress

  Boss   Name   First EP   Ally   Status
  ------ ------ ---------- ------ --------
  B1     미정   -          예정   LOCK
  B2     미정   -          예정   LOCK
  B3     미정   -          예정   LOCK
  B4     미정   -          예정   LOCK
  B5     미정   -          예정   LOCK
  B6     미정   -          예정   LOCK
  B7     미정   -          예정   LOCK

# Episode Checklist

- [x] EP001
- [x] EP002
- [x] EP003
- [x] EP004
- [x] EP005
- [x] EP006
- [x] EP007
- [ ] EP008
